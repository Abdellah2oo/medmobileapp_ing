import 'package:flutter/material.dart';
import 'package:medmobileapp_ing/models/doctor.dart';
import 'package:medmobileapp_ing/screens/doctor_info_screen.dart';
import 'package:medmobileapp_ing/screens/doctors.dart';

// ——— بيانات الأطباء ———
final List<Doctor> doctors = [
  Doctor(
    name: "Dr. Alexander Bennett, Ph.D.",
    specialty: "Dermato-Genetics",
    rating: 5,
    reviews: 40,
    imageUrl: "assets/images/doctor1.png",
    experience: "15 years",
    focusArea: "Focus: The impact of hormonal imbalances on skin conditions...",
    schedule: "Mon-Sat / 9:00AM - 5:00PM",
  ),
  Doctor(
    name: "Dr. Michael Davidson, M.D.",
    specialty: "Solar Dermatology",
    rating: 4.8,
    reviews: 30,
    imageUrl: "assets/images/doctor2.png",
    experience: "12 years",
    focusArea: "Specializes in solar-related skin issues...",
    schedule: "Mon-Fri / 8:00AM - 4:00PM",
  ),
  Doctor(
    name: "Dr. Olivia Turner, M.D.",
    specialty: "Dermato-Endocrinology",
    rating: 5,
    reviews: 60,
    imageUrl: "assets/images/doctor3.png",
    experience: "10 years",
    focusArea: "Treatment and prevention of skin and photodermatitis.",
    schedule: "Tue-Sat / 10:00AM - 5:00PM",
  ),
  Doctor(
    name: "Dr. Sophia Martinez, Ph.D.",
    specialty: "Cosmetic Bioengineering",
    rating: 5,
    reviews: 150,
    imageUrl: "assets/images/doctor4.png",
    experience: "8 years",
    focusArea: "Specializes in cosmetic bioengineering treatments.",
    schedule: "Mon-Fri / 11:00AM - 7:00PM",
  ),
];

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        currentIndex: 0,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: "Messages"),
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today), label: "Appointment"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
      body: SafeArea(
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Row(
                children: [
                  // ✅ زر البروفايل
                  InkWell(
                    onTap: () {
                      //print("فتح صفحة البروفايل");
                      // Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen()));
                    },
                    child: const CircleAvatar(
                      radius: 24,
                      backgroundImage: AssetImage("assets/images/profile.png"),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Hi, WelcomeBack",
                          style: TextStyle(color: Colors.grey)),
                      Text("Abdellah Djadour",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const Spacer(),

                  // ✅ زر الإشعارات
                  IconButton(
                    icon: const Icon(Icons.notifications_none),
                    onPressed: () {
                      //  print("فتح الإشعارات");
                      // Navigator.push(context, MaterialPageRoute(builder: (_) => NotificationsScreen()));
                    },
                  ),

                  // ✅ زر الإعدادات
                  IconButton(
                    icon: const Icon(Icons.settings),
                    onPressed: () {
                      //  print("فتح الإعدادات");
                      // Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen()));
                    },
                  ),
                ],
              ),
            ),

            // Tabs
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Row(
                children: [
                  // ✅ زر Doctors
                  InkWell(
                    onTap: () {
                      //print("فتح قائمة الأطباء");
                      Navigator.push(context,
                          MaterialPageRoute(builder: (_) => DoctorsScreen()));
                    },
                    child: Row(
                      children: const [
                        Icon(Icons.medical_services_outlined,
                            color: Colors.blue),
                        SizedBox(width: 8),
                        Text("Doctors",
                            style: TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // ✅ زر المفضلة
                  IconButton(
                    icon: const Icon(Icons.favorite_border),
                    onPressed: () {
                      //print("فتح المفضلة");
                      // Navigator.push(context, MaterialPageRoute(builder: (_) => FavoritesScreen()));
                    },
                  ),

                  // ✅ زر الفلتر
                  IconButton(
                    icon: const Icon(Icons.filter_alt_outlined),
                    onPressed: () {
                      //print("فتح الفلترة");
                      // Navigator.push(context, MaterialPageRoute(builder: (_) => FilterScreen()));
                    },
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Days row
            SizedBox(
              height: 70,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: List.generate(6, (index) {
                  final dates = [
                    "9\nMON",
                    "10\nTUE",
                    "11\nWED",
                    "12\nTHU",
                    "13\nFRI",
                    "14\nSAT"
                  ];
                  final isSelected = index == 2; // يوم 11 هو المحدد
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: 50,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.blue : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blue.shade100),
                    ),
                    child: Text(
                      dates[index],
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  );
                }),
              ),
            ),

            const SizedBox(height: 16),

            // موعد محجوز
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFE9EEFF),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("10 AM",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    SizedBox(height: 4),
                    Text("Dr. Olivia Turner, M.D."),
                    SizedBox(height: 4),
                    Text(
                      "Treatment and prevention of skin and photodermatitis.",
                      style: TextStyle(color: Colors.black54),
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Icon(Icons.close, size: 20),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // قائمة الأطباء
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: doctors
                    .map((doctor) => doctorCard(context, doctor))
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

// 📦 عنصر واجهة لعرض بطاقة دكتور
  Widget doctorCard(BuildContext context, Doctor doctor) {
    return InkWell(
      onTap: () {
        // الانتقال إلى صفحة تفاصيل الدكتور
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DoctorInfoScreen(doctor: doctor),
          ),
        );
      },
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF3F6FD),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            // صورة الدكتور
            CircleAvatar(
              radius: 30,
              backgroundImage: AssetImage(doctor.imageUrl),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // اسم الدكتور
                  Text(
                    doctor.name,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),

                  // التخصص
                  Text(
                    doctor.specialty,
                    style: const TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 6),

                  // تقييم وعدد المراجعات
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 16),
                      const SizedBox(width: 4),
                      Text(
                        "${doctor.rating}",
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(width: 12),
                      const Icon(Icons.people, color: Colors.grey, size: 16),
                      const SizedBox(width: 4),
                      Text("${doctor.reviews}"),

                      const Spacer(),

                      // أيقونة المفضلة والاستفسار
                      const Icon(Icons.favorite_border),
                      const SizedBox(width: 6),
                      const Icon(Icons.help_outline),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

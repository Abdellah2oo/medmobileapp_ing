import 'package:flutter/material.dart';
import '../models/doctor.dart';

class DoctorInfoScreen extends StatelessWidget {
  final Doctor doctor;

  const DoctorInfoScreen({super.key, required this.doctor});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Doctor Info'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // صورة الدكتور
            CircleAvatar(
              radius: 60,
              backgroundImage: AssetImage(doctor.imageUrl),
            ),
            const SizedBox(height: 16),
            
            // اسم الدكتور
            Text(
              doctor.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),

            // التخصص
            Text(
              doctor.specialty,
              style: const TextStyle(fontSize: 18, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),

            // التقييم وعدد المراجعات
            Text(
              '⭐ ${doctor.rating} (${doctor.reviews} Reviews)',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8),

            // الخبرة
            Text(
              'Experience: ${doctor.experience}',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8),

            // المواعيد
            Text(
              'Schedule: ${doctor.schedule}',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),

            // زر جدولة موعد
            ElevatedButton.icon(
              onPressed: () {
                // هنا ممكن تفتح صفحة جدولة موعد لاحقاً
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Schedule Appointment Clicked')),
                );
              },
              icon: const Icon(Icons.calendar_today),
              label: const Text('Schedule Appointment'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // المنطقة الخاصة بالـ Focus Area
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                doctor.focusArea,
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
